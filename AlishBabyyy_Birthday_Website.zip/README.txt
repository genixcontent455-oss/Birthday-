# AlishBabyyy Birthday Website

Open `index.html` in a browser to preview it.

Replace the six photo placeholders with your own images. For music, use an audio file you have permission to use rather than redistributing a copyrighted recording.
